package clusterdata.utils;

public class JobEventSchema {
}
